# Welcome To Our Graduation Project Repo
Please Note that this code written by :[Ahmed Ali](https://www.linkedin.com/in/ahmed-elsaify-0b553a232/) and [Abdelrahman Osama](https://www.linkedin.com/in/abdelrahmanosama74/)

where:
[Ahmed Ali](https://www.linkedin.com/in/ahmed-elsaify-0b553a232/) was responsible for Embedded System Part
,[Abdelrahman Osama](https://www.linkedin.com/in/abdelrahmanosama74/)  was responsible for AI Part

Thanks for being here <3
