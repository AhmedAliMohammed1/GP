detect_frontal_face = 'src/haarcascades/haarcascade_frontalface_alt.xml'
detect_perfil_face = 'src/haarcascades/haarcascade_profileface.xml'